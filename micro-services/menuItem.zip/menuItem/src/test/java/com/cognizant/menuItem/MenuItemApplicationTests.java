package com.cognizant.menuItem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
