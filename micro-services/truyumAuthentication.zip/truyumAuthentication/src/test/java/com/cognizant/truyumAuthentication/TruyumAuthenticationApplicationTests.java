package com.cognizant.truyumAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruyumAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
