package com.cognizant.truyumSignUp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruyumSignUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
